function plotEigenvalues( lamda )
% a simple function plotting the eigenvalues returned from a
% eigendecomposition
eigenvalues = diag(lamda);


plot(eigenvalues);

end

